extends Control
## Animated Jimothy — bush rustle, walk/run/jump, form variance, adult short-spine look.

signal ascend_finished

var stage: String = "bush"
var young_form: String = "puff"
var teen_form: String = "bounder"
var adult_form: String = "saint"
var genes: Dictionary = {}
var mood: String = "idle"

var _t: float = 0.0
var _pose_x: float = 0.0
var _pose_y: float = 0.0
var _facing: float = 1.0
var _anim: String = "idle"
var _anim_t: float = 0.0
var _anim_dur: float = 1.2
var _walk_phase: float = 0.0
var _jump_peak: float = 0.0
var _target_x: float = 0.0
var _speed: float = 0.0
var _eat_flash: float = 0.0
var _eat_food: String = "berry"
var _head_dip: float = 0.0
var _body_squash: float = 1.0
var _smile: float = 0.0
var _wing_span: float = 0.0
var _fade: float = 1.0
var _ascend_done_emitted: bool = false
var _tap_cooldown: float = 0.0


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	gui_input.connect(_on_gui_input)
	if PetState:
		PetState.anim_impulse.connect(play_anim)
		PetState.state_changed.connect(_sync_from_state)
		_sync_from_state()
		# Only resume an in-progress ascension — never replay for a dead save.
		if PetState.ascending and not PetState.alive:
			play_anim("ascend")


func _on_gui_input(event: InputEvent) -> void:
	if event is InputEventScreenTouch and event.pressed:
		_try_tap()
		accept_event()
	elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_try_tap()
		accept_event()


func _try_tap() -> void:
	if _tap_cooldown > 0.0:
		return
	if PetState == null:
		return
	if PetState.ascending or not PetState.alive:
		return
	# Don't interrupt eat / ascend mid-motion
	if _anim in ["eat", "ascend"]:
		return
	_tap_cooldown = 0.55
	PetState.interact_tap()


func clear_ascend() -> void:
	_anim = "idle"
	_anim_t = 0.0
	_pose_x = 0.0
	_pose_y = 0.0
	_wing_span = 0.0
	_fade = 1.0
	_head_dip = 0.0
	_body_squash = 1.0
	_ascend_done_emitted = false
	_speed = 0.0
	modulate = Color(1, 1, 1, 1)
	_sync_from_state()


func play_eat(food_kind: String = "berry") -> void:
	_eat_food = food_kind if food_kind != "" else "berry"
	play_anim("eat")


func _sync_from_state() -> void:
	var p: Dictionary = PetState.form_profile()
	stage = str(p.stage)
	young_form = str(p.young_form)
	teen_form = str(p.teen_form)
	adult_form = str(p.adult_form)
	genes = p.genes if typeof(p.genes) == TYPE_DICTIONARY else {}
	if PetState.ascending and _anim == "ascend":
		mood = "ascend"
	elif PetState.stubborn:
		mood = "stubborn"
	elif PetState.sick:
		mood = "sick"
	else:
		mood = "idle"
	queue_redraw()


func set_look(_stage: String, _variant: String = "", _mood: String = "idle") -> void:
	# Kept for main.gd compatibility; prefer PetState sync.
	mood = _mood
	_sync_from_state()


func play_anim(kind: String) -> void:
	_anim = kind
	_anim_t = 0.0
	match kind:
		"ascend":
			_anim_dur = 4.2
			_wing_span = 0.0
			_fade = 1.0
			_ascend_done_emitted = false
			_speed = 0.0
		"run":
			_anim_dur = randf_range(1.4, 2.4)
			_speed = randf_range(90.0, 140.0)
			_target_x = randf_range(-70.0, 70.0)
			_facing = signf(_target_x - _pose_x)
			if _facing == 0.0:
				_facing = 1.0
		"walk", "lope":
			_anim_dur = randf_range(1.8, 3.2)
			_speed = randf_range(35.0, 70.0) if kind == "walk" else randf_range(55.0, 95.0)
			_target_x = randf_range(-65.0, 65.0)
			_facing = signf(_target_x - _pose_x)
			if _facing == 0.0:
				_facing = [-1.0, 1.0][randi() % 2]
		"jump":
			_anim_dur = randf_range(0.55, 0.9)
			_jump_peak = randf_range(18.0, 36.0)
			_facing = [-1.0, 1.0][randi() % 2]
			_target_x = clampf(_pose_x + _facing * randf_range(20.0, 50.0), -70.0, 70.0)
		"pop":
			_anim_dur = 0.85
			_body_squash = 1.0
		"stretch":
			_anim_dur = 1.05
			_body_squash = 1.0
		"eat":
			_anim_dur = 1.15
			_eat_flash = 1.0
			_head_dip = 0.0
			if PetState and PetState.last_fed_food != "":
				_eat_food = PetState.last_fed_food
		"refuse":
			_anim_dur = 0.95
		"scold":
			_anim_dur = 0.9
		"stubborn", "sick":
			_anim_dur = 1.1
		"sniff":
			_anim_dur = 1.0
		"smile":
			_anim_dur = 0.95
			_smile = 1.0
		"hop":
			_anim_dur = 0.7
			_jump_peak = randf_range(22.0, 34.0)
		"nuzzle":
			_anim_dur = 0.9
			_smile = 0.7
		"spin":
			_anim_dur = 0.85
		"rustle":
			_anim_dur = 0.7
		"happy":
			_anim_dur = 0.8
			_smile = 1.0
			_jump_peak = 16.0
		_:
			_anim_dur = randf_range(1.0, 2.0)
			_speed = 0.0


func _process(delta: float) -> void:
	_t += delta
	_anim_t += delta
	_tap_cooldown = maxf(0.0, _tap_cooldown - delta)
	_eat_flash = maxf(0.0, _eat_flash - delta * 0.85)
	if _anim not in ["smile", "nuzzle", "happy"]:
		_smile = maxf(0.0, _smile - delta * 1.8)

	if _anim == "ascend":
		var u := clampf(_anim_t / _anim_dur, 0.0, 1.0)
		_wing_span = smoothstep(0.0, 0.45, u)
		_pose_y = -u * 160.0 - sin(u * PI) * 12.0
		_pose_x = sin(_t * 1.6) * (8.0 * (1.0 - u * 0.5))
		_fade = 1.0 - smoothstep(0.55, 1.0, u)
		queue_redraw()
		if u >= 1.0 and not _ascend_done_emitted:
			_ascend_done_emitted = true
			ascend_finished.emit()
		return

	if stage == "bush":
		var bush_amp := 2.0
		if _anim == "rustle":
			bush_amp = 5.0 + sin(_anim_t * 28.0) * 2.0
			if _anim_t >= _anim_dur:
				_anim = "idle"
		_pose_x = sin(_t * 9.0) * bush_amp + sin(_t * 3.3) * (bush_amp * 0.7)
		_pose_y = sin(_t * 7.0) * (bush_amp * 0.7)
		queue_redraw()
		return

	match _anim:
		"walk", "run", "lope":
			var dir := signf(_target_x - _pose_x)
			if dir == 0.0:
				dir = _facing
			_facing = dir
			_pose_x = move_toward(_pose_x, _target_x, _speed * delta)
			_walk_phase += delta * (_speed * 0.12)
			_pose_y = absf(sin(_walk_phase)) * (3.0 if _anim == "walk" else 5.5)
			_head_dip = sin(_walk_phase * 2.0) * 1.2
			_body_squash = 1.0
			if absf(_pose_x - _target_x) < 1.5 or _anim_t >= _anim_dur:
				if randf() < 0.45 and _anim_t < _anim_dur:
					_target_x = randf_range(-70.0, 70.0)
					_facing = signf(_target_x - _pose_x)
				else:
					_anim = "idle"
					_pose_y = 0.0
					_head_dip = 0.0
		"jump":
			var u := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_y = -sin(u * PI) * _jump_peak
			_pose_x = lerpf(_pose_x, _target_x, delta * 3.5)
			_body_squash = 1.0 + sin(u * PI) * 0.08
			if u >= 1.0:
				_anim = "idle"
				_pose_y = 0.0
				_body_squash = 1.0
		"pop":
			var pu := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_y = -ease(pu, 0.3) * 22.0
			_body_squash = 1.0 + (1.0 - pu) * 0.15
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_pose_y = 0.0
				_body_squash = 1.0
		"stretch":
			var su := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_y = -sin(su * PI) * 6.0
			_body_squash = 1.0 + sin(su * PI) * 0.22
			_head_dip = -sin(su * PI) * 4.0
			_walk_phase += delta * 4.0
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_pose_y = 0.0
				_body_squash = 1.0
				_head_dip = 0.0
		"eat":
			var eu := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			# Reach → chew → settle
			if eu < 0.22:
				_head_dip = lerpf(0.0, 10.0, eu / 0.22)
				_pose_y = lerpf(0.0, 3.0, eu / 0.22)
			elif eu < 0.78:
				_head_dip = 8.0 + sin(_t * 22.0) * 2.5
				_pose_y = 2.0 + sin(_t * 18.0) * 1.5
				_walk_phase += delta * 10.0
			else:
				var settle := (eu - 0.78) / 0.22
				_head_dip = lerpf(8.0, 0.0, settle)
				_pose_y = lerpf(2.0, 0.0, settle)
			_eat_flash = 1.0 - eu * 0.85
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
				_pose_y = 0.0
		"refuse":
			var ru := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_facing = -1.0 if int(_t * 8.0) % 2 == 0 else 1.0
			_pose_x += sin(_t * 20.0) * 1.1
			_head_dip = sin(ru * PI) * 4.0
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
		"scold":
			var cu := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_y = sin(cu * PI) * 2.0
			_head_dip = 3.0 + sin(_t * 14.0) * 2.0
			_body_squash = 0.94
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
				_body_squash = 1.0
		"sniff":
			_head_dip = 6.0 + sin(_t * 10.0) * 2.0
			_pose_y = sin(_t * 3.0) * 1.0
			_facing = 1.0 if sin(_t * 1.4) > 0.0 else -1.0
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
		"smile":
			var sm := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_smile = 1.0
			_pose_y = sin(sm * PI) * 3.0
			_head_dip = -sin(sm * PI) * 2.0
			_body_squash = 1.0 + sin(sm * PI) * 0.04
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
		"hop", "happy":
			var hu := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_y = -sin(hu * PI) * _jump_peak
			_smile = 0.85
			_body_squash = 1.0 + sin(hu * PI) * 0.1
			if hu >= 1.0:
				_anim = "idle"
				_pose_y = 0.0
				_body_squash = 1.0
		"nuzzle":
			var nu := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_pose_x += sin(_t * 10.0) * 0.8
			_head_dip = 4.0 + sin(nu * PI) * 5.0
			_facing = 1.0 if sin(_t * 6.0) > 0.0 else -1.0
			_smile = 0.8
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_head_dip = 0.0
		"spin":
			var su2 := clampf(_anim_t / _anim_dur, 0.0, 1.0)
			_facing = 1.0 if int(su2 * 8.0) % 2 == 0 else -1.0
			_pose_y = -sin(su2 * PI) * 10.0
			_pose_x += sin(_t * 20.0) * 1.2
			_smile = 0.6
			if _anim_t >= _anim_dur:
				_anim = "idle"
				_pose_y = 0.0
		"stubborn", "sick":
			_pose_x += sin(_t * 16.0) * 0.55
			_head_dip = 2.0
			if _anim_t >= _anim_dur:
				_anim = "idle"
		_:
			# Livelier idle: bob, look around, tiny weight shifts
			_pose_y = sin(_t * 2.4) * 2.2 + sin(_t * 5.1) * 0.6
			_pose_x = move_toward(_pose_x, sin(_t * 0.4) * 10.0 + sin(_t * 0.13) * 4.0, 12.0 * delta)
			_head_dip = sin(_t * 1.7) * 1.4
			_body_squash = 1.0 + sin(_t * 2.4) * 0.02
			_walk_phase += delta * 1.2
			if int(_t * 2.0) % 11 == 0 and randf() < 0.02:
				_facing *= -1.0

	_pose_x = clampf(_pose_x, -75.0, 75.0)
	queue_redraw()


func _ellipse(center: Vector2, radii: Vector2, color: Color, points: int = 26) -> void:
	var pts := PackedVector2Array()
	for i in points:
		var a := TAU * float(i) / float(points)
		pts.append(center + Vector2(cos(a) * radii.x, sin(a) * radii.y))
	draw_colored_polygon(pts, color)


func _g(key: String, fallback: float = 0.5) -> float:
	return float(genes.get(key, fallback))


func _fur() -> Color:
	var g := _g("gray", 0.5)
	var base := Color(0.42 + g * 0.08, 0.42 + g * 0.06, 0.46 + g * 0.05)
	if stage == "adult" and adult_form == "alley_ghost":
		base = base.darkened(0.1)
	return base


func _draw() -> void:
	_draw_clearing()
	var c := size * 0.5 + Vector2(_pose_x, _pose_y)
	if stage == "bush" and _anim != "ascend":
		_draw_bush(size * 0.5)
		return

	# Soft sky glow during ascent
	if _anim == "ascend":
		var glow_a := (1.0 - _fade) * 0.35 + _wing_span * 0.25
		_ellipse(c + Vector2(0, 10), Vector2(70, 40), Color(0.95, 0.88, 0.55, glow_a * 0.35))

	var face := _facing if _facing != 0.0 else 1.0
	var old_mod := modulate
	if _anim == "ascend":
		modulate = Color(1, 1, 1, _fade)

	if _anim == "ascend" and _wing_span > 0.05:
		_draw_wings(c, face, _wing_span)

	# Head dip nudges the silhouette down while chewing / sniffing.
	var draw_c := c + Vector2(0, _head_dip * 0.45)

	match stage:
		"baby":
			_draw_baby(draw_c, face)
		"young":
			_draw_young(draw_c, face)
		"teen":
			_draw_teen(draw_c, face)
		"adult":
			_draw_adult(draw_c, face)
		_:
			_draw_baby(draw_c, face)

	if _anim == "eat" and _eat_flash > 0.05:
		_draw_food_prop(c, face, clampf(_anim_t / _anim_dur, 0.0, 1.0))

	modulate = old_mod


func _draw_food_prop(c: Vector2, face: float, u: float) -> void:
	# Food arcs from paws up to muzzle, then fades while chewing.
	var reach := smoothstep(0.0, 0.28, u)
	var fade := 1.0 - smoothstep(0.55, 0.95, u)
	var paw := c + Vector2(14.0 * face, 18.0)
	var mouth := c + Vector2(2.0 * face, -2.0 + _head_dip)
	var p := paw.lerp(mouth, reach)
	p += Vector2(sin(u * PI) * -6.0 * face, -sin(reach * PI) * 10.0)
	var a := fade * 0.95
	match _eat_food:
		"pizza", "fries":
			_ellipse(p, Vector2(7, 4), Color(0.88, 0.63, 0.29, a))
			draw_line(p + Vector2(-5, -1), p + Vector2(5, -1), Color(0.77, 0.36, 0.29, a), 2.0)
		"fish":
			_ellipse(p, Vector2(8, 3.5), Color(0.66, 0.77, 0.83, a))
		"crickets":
			_ellipse(p, Vector2(5, 3), Color(0.42, 0.48, 0.28, a))
		_:
			_ellipse(p + Vector2(-3, 0), Vector2(4.5, 4.5), Color(0.42, 0.35, 0.63, a))
			_ellipse(p + Vector2(3, -1), Vector2(4.5, 4.5), Color(0.42, 0.35, 0.63, a))


func _draw_wings(c: Vector2, face: float, span: float) -> void:
	var spread := 28.0 + span * 46.0
	var flap := sin(_t * 7.0) * (6.0 + span * 10.0)
	var wing_col := Color(0.92, 0.9, 0.82, 0.55 + span * 0.35)
	var edge := Color(0.85, 0.78, 0.45, 0.4 + span * 0.4)
	# Left wing
	var l := PackedVector2Array([
		c + Vector2(-8, -4),
		c + Vector2(-spread * 0.55, -18 + flap),
		c + Vector2(-spread, -2 + flap * 0.4),
		c + Vector2(-spread * 0.6, 14),
		c + Vector2(-10, 6),
	])
	draw_colored_polygon(l, wing_col)
	draw_polyline(l, edge, 1.5, true)
	# Right wing
	var r := PackedVector2Array([
		c + Vector2(8, -4),
		c + Vector2(spread * 0.55, -18 - flap),
		c + Vector2(spread, -2 - flap * 0.4),
		c + Vector2(spread * 0.6, 14),
		c + Vector2(10, 6),
	])
	draw_colored_polygon(r, wing_col)
	draw_polyline(r, edge, 1.5, true)
	# Tiny sparkles
	for i in 4:
		var sx := sin(_t * 3.0 + i * 1.7) * spread * 0.7
		var sy := -20.0 - i * 8.0 - span * 20.0
		draw_circle(c + Vector2(sx, sy), 1.6, Color(1, 0.95, 0.7, 0.35 + span * 0.4))
	if face < 0.0:
		pass


func _draw_clearing() -> void:
	# Forest floor inside the pet screen
	var ground_y := size.y * 0.78
	_ellipse(Vector2(size.x * 0.5, ground_y), Vector2(size.x * 0.48, 18), Color(0.12, 0.18, 0.12, 0.55))
	_ellipse(Vector2(size.x * 0.35, ground_y + 2), Vector2(22, 7), Color(0.18, 0.14, 0.08, 0.25))
	_ellipse(Vector2(size.x * 0.65, ground_y + 1), Vector2(18, 6), Color(0.16, 0.22, 0.12, 0.3))
	# Leaf flecks
	for i in 5:
		var lx := size.x * (0.2 + float(i) * 0.14)
		draw_colored_polygon(PackedVector2Array([
			Vector2(lx, ground_y - 2),
			Vector2(lx + 5, ground_y),
			Vector2(lx + 1, ground_y + 3),
		]), Color(0.35, 0.22, 0.1, 0.45))


func _draw_bush(c: Vector2) -> void:
	var rustle := sin(_t * 10.0) * 3.0
	var rustle2 := cos(_t * 7.5) * 2.0
	# Ground shadow
	_ellipse(c + Vector2(0, 46), Vector2(48, 10), Color(0, 0, 0, 0.25))
	# Layered foliage
	_ellipse(c + Vector2(-18 + rustle, 18), Vector2(26, 22), Color("2f5a3c"))
	_ellipse(c + Vector2(16 + rustle2, 20), Vector2(28, 24), Color("3d6b4f"))
	_ellipse(c + Vector2(0, 8 + rustle * 0.3), Vector2(34, 28), Color("355f44"))
	_ellipse(c + Vector2(-8, -6 + rustle2), Vector2(18, 16), Color("4a8a5e"))
	_ellipse(c + Vector2(12, -2 + rustle), Vector2(16, 14), Color("6fbf84").darkened(0.25))
	# Occasional eye glint in the leaves near reveal
	if age_hint() > 0.7:
		draw_circle(c + Vector2(-4 + rustle, 6), 2.2, Color(0.98, 0.96, 0.9, 0.55))
		draw_circle(c + Vector2(6 + rustle2, 8), 2.2, Color(0.98, 0.96, 0.9, 0.45))


func age_hint() -> float:
	# 0..1 through bush stage for tease glints
	if stage != "bush":
		return 1.0
	return clampf(PetState.age_sec / 60.0, 0.0, 1.0)


func _leg(a: Vector2, b: Vector2, width: float, phase: float, amp: float) -> void:
	var kick := sin(phase) * amp
	var mid := (a + b) * 0.5 + Vector2(0, kick)
	draw_line(a, mid, Color("4f4f58"), width)
	draw_line(mid, b + Vector2(0, absf(kick) * 0.3), Color("4f4f58"), width)
	_ellipse(b + Vector2(0, absf(kick) * 0.3), Vector2(7, 4), Color("3a3a44"))


func _ears(c: Vector2, spread: float, up: float, face: float) -> void:
	var flare := 1.0 + _g("ear_flare") * 0.35
	_ellipse(c + Vector2(-spread * face, -up), Vector2(7 * flare, 11 * flare), Color("4a4a54"))
	_ellipse(c + Vector2(spread * face, -up), Vector2(7 * flare, 11 * flare), Color("4a4a54"))
	_ellipse(c + Vector2(-spread * face, -up), Vector2(4, 6), Color("e2cdb2"))
	_ellipse(c + Vector2(spread * face, -up), Vector2(4, 6), Color("e2cdb2"))


func _mask(c: Vector2, rx: float, ry: float, eye: float, face: float) -> void:
	var mask_c := Color("1c1c22").lightened((1.0 - _g("mask")) * 0.15)
	_ellipse(c, Vector2(rx, ry), mask_c)
	if _smile > 0.35:
		# Happy closed eyes + soft grin
		var eye_y := -1.0 - _smile
		draw_line(c + Vector2(-eye * 1.7 * face, eye_y), c + Vector2(-eye * 0.85 * face, eye_y - 1.5 * _smile), Color("faf6ec"), 2.2)
		draw_line(c + Vector2(-eye * 0.85 * face, eye_y - 1.5 * _smile), c + Vector2(-eye * 0.35 * face, eye_y), Color("faf6ec"), 2.2)
		draw_line(c + Vector2(eye * 0.35 * face, eye_y), c + Vector2(eye * 0.85 * face, eye_y - 1.5 * _smile), Color("faf6ec"), 2.2)
		draw_line(c + Vector2(eye * 0.85 * face, eye_y - 1.5 * _smile), c + Vector2(eye * 1.7 * face, eye_y), Color("faf6ec"), 2.2)
		_ellipse(c + Vector2(0, eye * 1.35), Vector2(eye * (1.35 + _smile * 0.35), eye * 0.85), Color("c9a292"))
		# Pink cheek blush
		_ellipse(c + Vector2(-eye * 2.1 * face, eye * 0.6), Vector2(eye * 0.7, eye * 0.4), Color(0.9, 0.55, 0.55, 0.35 * _smile))
		_ellipse(c + Vector2(eye * 2.1 * face, eye * 0.6), Vector2(eye * 0.7, eye * 0.4), Color(0.9, 0.55, 0.55, 0.35 * _smile))
	else:
		draw_circle(c + Vector2(-eye * 1.35 * face, -1), eye, Color("faf6ec"))
		draw_circle(c + Vector2(eye * 1.35 * face, -1), eye, Color("faf6ec"))
		draw_circle(c + Vector2(-eye * 1.15 * face, -0.3), eye * 0.45, Color("101014"))
		draw_circle(c + Vector2(eye * 1.55 * face, -0.3), eye * 0.45, Color("101014"))
		_ellipse(c + Vector2(0, eye * 1.15), Vector2(eye * 1.1, eye * 0.7), Color("c9a292"))


func _tail(base: Vector2, scale: float, face: float) -> void:
	var tip := base + Vector2(26 * scale * -face, -6 * scale)
	draw_line(base, tip, Color("5a5a64"), 9.0 * scale)
	draw_line(base + Vector2(3 * -face, 2), base + Vector2(14 * scale * -face, 8 * scale), Color("b0b0ba"), 2.5)


func _draw_baby(c: Vector2, face: float) -> void:
	_ellipse(c + Vector2(0, 40), Vector2(18, 5), Color(0, 0, 0, 0.2))
	var wobble := sin(_walk_phase) * 2.0
	_ellipse(c + Vector2(0, 14 + wobble), Vector2(18, 14), _fur())
	draw_circle(c + Vector2(0, -2), 14.0, _fur().lightened(0.05))
	_ears(c + Vector2(0, -2), 11.0, 10.0, face)
	_mask(c + Vector2(0, 0), 11.0, 7.0, 2.6, face)
	# Tiny stubby paws
	_ellipse(c + Vector2(-10, 24), Vector2(5, 3), Color("3a3a44"))
	_ellipse(c + Vector2(10, 24), Vector2(5, 3), Color("3a3a44"))


func _draw_young(c: Vector2, face: float) -> void:
	_ellipse(c + Vector2(0, 44), Vector2(24, 6), Color(0, 0, 0, 0.2))
	var roundness := _g("roundness")
	var legs := 0.7 + _g("legginess") * 0.8
	var body_rx := 22.0 + roundness * 8.0
	var body_ry := 16.0 + (1.0 - roundness) * 4.0
	if young_form == "puff":
		body_rx += 4.0
		body_ry += 3.0
	elif young_form == "looper":
		legs += 0.35
	elif young_form == "shadow":
		pass
	elif young_form == "nub":
		body_rx -= 2.0
		legs -= 0.15

	_tail(c + Vector2(18 * -face, 8), 0.75, face)
	var phase := _walk_phase
	_leg(c + Vector2(-12, 10), c + Vector2(-14, 10 + 22 * legs), 4.5, phase, 3.0)
	_leg(c + Vector2(-4, 12), c + Vector2(-2, 10 + 24 * legs), 4.5, phase + 1.2, 3.0)
	_leg(c + Vector2(4, 12), c + Vector2(6, 10 + 24 * legs), 4.5, phase + 3.0, 3.0)
	_leg(c + Vector2(12, 10), c + Vector2(16, 10 + 22 * legs), 4.5, phase + 4.2, 3.0)
	_ellipse(c + Vector2(0, 6), Vector2(body_rx, body_ry), _fur())
	draw_circle(c + Vector2(0, -8), 16.0 + roundness * 3.0, _fur().lightened(0.04))
	_ears(c + Vector2(0, -8), 14.0, 12.0, face)
	_mask(c + Vector2(0, -6), 14.0, 9.0, 3.3, face)


func _draw_teen(c: Vector2, face: float) -> void:
	_ellipse(c + Vector2(0, 48), Vector2(28, 6), Color(0, 0, 0, 0.22))
	var form := teen_form if teen_form != "" else "bounder"
	var legs := 1.0 + _g("legginess") * 0.7
	var roundness := _g("roundness")
	if form == "bounder":
		legs += 0.4
	elif form == "dumpling":
		roundness = maxf(roundness, 0.7)
		legs -= 0.1
	elif form == "nightlane":
		legs += 0.2
	elif form == "scruff":
		roundness *= 0.8

	_tail(c + Vector2(22 * -face, 4), 0.9, face)
	var phase := _walk_phase
	_leg(c + Vector2(-16, 8), c + Vector2(-20, 8 + 28 * legs), 5.2, phase, 4.0)
	_leg(c + Vector2(-6, 10), c + Vector2(-8, 8 + 30 * legs), 5.2, phase + 1.1, 4.0)
	_leg(c + Vector2(6, 10), c + Vector2(10, 8 + 30 * legs), 5.2, phase + 2.8, 4.0)
	_leg(c + Vector2(16, 8), c + Vector2(22, 8 + 28 * legs), 5.2, phase + 4.0, 4.0)
	# Body shortening begins (teen foreshadow)
	_ellipse(c + Vector2(0, 2), Vector2(26 + roundness * 6.0, 20 + (1.0 - roundness) * 3.0), _fur())
	draw_circle(c + Vector2(0, -10), 18.0, _fur().lightened(0.03))
	_ears(c + Vector2(0, -10), 16.0, 14.0, face)
	_mask(c + Vector2(0, -8), 16.0, 10.0, 3.8, face)


func _draw_adult(c: Vector2, face: float) -> void:
	# Viral short-spine Jimothy: round body, long legs, almost no neck — with form flair.
	_ellipse(c + Vector2(0, 52), Vector2(34, 7), Color(0, 0, 0, 0.22))
	var legs := 1.25 + _g("legginess") * 0.45
	var roundness := 0.7 + _g("roundness") * 0.3
	var body_rx := 30.0 + roundness * 8.0
	var body_ry := 26.0 + roundness * 4.0

	_tail(c + Vector2(24 * -face, 0), 1.05, face)
	var phase := _walk_phase
	var amp := 5.0 if _anim in ["run", "lope"] else 3.5
	_leg(c + Vector2(-18, 6), c + Vector2(-30, 6 + 36 * legs), 6.0, phase, amp)
	_leg(c + Vector2(-8, 10), c + Vector2(-12, 6 + 38 * legs), 6.0, phase + 1.0, amp)
	_leg(c + Vector2(8, 10), c + Vector2(14, 6 + 38 * legs), 6.0, phase + 2.7, amp)
	_leg(c + Vector2(18, 6), c + Vector2(32, 6 + 36 * legs), 6.0, phase + 3.9, amp)

	# One fused potato body
	_ellipse(c + Vector2(0, -2), Vector2(body_rx, body_ry), _fur())
	_ears(c + Vector2(0, -2), 20.0, 24.0, face)
	_mask(c + Vector2(0, -4), 20.0, 12.0, 4.6, face)

	# Adult flair still reads as Jimothy
	match adult_form:
		"saint":
			_ellipse(c + Vector2(16 * face, -18), Vector2(7, 4), Color("6fbf84"))
		"legend":
			var pts := PackedVector2Array([
				c + Vector2(16 * face, -14),
				c + Vector2(28 * face, 0),
				c + Vector2(14 * face, 2),
			])
			draw_colored_polygon(pts, Color("e0a04a"))
		"alley_ghost":
			draw_circle(c + Vector2(18 * face, -8), 3.0, Color(0.85, 0.9, 0.95, 0.55))
		"ballard_blip":
			_ellipse(c + Vector2(0, 8), Vector2(10, 5), Color(0.88, 0.63, 0.29, 0.35))
