# Jimothy

Your **midnight cryptid** — a real-time Tamagotchi-style pet starring Jimothy (viral short-spine look at adult stage).

## Play in Godot 4.7.1 (recommended for Android)

The game is set up as a **Godot 4.7.1** project:

```text
godot/project.godot
```

1. Install [Godot 4.7.1](https://godotengine.org/download/archive/4.7.1-stable/)
2. Open / import the `godot/` folder
3. Press **Play (F5)**

See [`godot/README.md`](godot/README.md) for Android APK export and details.

## Play in browser (optional web build)

A standalone HTML version also lives at the repo root:

```bash
npm start
# open http://localhost:8080
```

## Life cycle (real time)

| Stage | When |
| --- | --- |
| **Rustling bush** | Start |
| **Baby kit** | ~1 minute |
| **Young kit** | +1 hour (form variance begins) |
| **Teen kit** | +24 hours (form steers adult) |
| **Adult Jimothy** | +24–72 hours more (short-spine viral look, variant flair) |
| **Lifespan** | Adult lasts ~10–20 days — neglect / poor care shortens it |
| **Finale** | Wings + sky ascension, then **Raise another kit** |

Young/teen forms (`puff` / `looper` / `shadow` / `nub` → `dumpling` / `bounder` / `nightlane` / `scruff`) influence adult flair (**Saint**, **Legend**, **Alley Ghost**, **Ballard Blip**) while keeping the short-spine silhouette.

Full wall-clock catch-up when you return (no 1-hour cap). Saves use `jimothy-pet-v2`.

## Care

| Action | What it does |
| --- | --- |
| **Feed** | Wild Berries, Night Crickets, Stream Fish Bits — or Pizza Crust / Dumpster Fries |
| **Play** | **Dumpster Dive** night forage — burns energy, builds fitness |
| **Scold** | Discipline when he acts up |
| **Clean** | Clear nest messes |

Satiety stops overfeeding; junk treats can make him sick. Baby kits and the bush can’t run a full Dumpster Dive. Jimothy walks, runs, jumps, and lopes around the stage.
